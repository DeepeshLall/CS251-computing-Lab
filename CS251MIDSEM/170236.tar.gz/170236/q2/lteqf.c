int lteqf(float a, float b){
	if(a<=b){
		return 1;
	}else{
		return 0;
	}
}