int ltll(long long int a, long long int b){
	if(a<b){
		return 1;
	}else{
		return 0;
	}
}