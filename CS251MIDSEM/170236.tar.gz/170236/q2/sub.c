long long int sub(long long int a, long long int b){
	return a-b;
}