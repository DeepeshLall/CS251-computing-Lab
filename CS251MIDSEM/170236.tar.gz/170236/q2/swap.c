void swap(float *a, float *b){
	float *temp;
	temp=a;
	a=b;
	b=temp;
	return;
}