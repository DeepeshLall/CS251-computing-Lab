long long int add(long long int a, long long int b){
	return a+b;
}