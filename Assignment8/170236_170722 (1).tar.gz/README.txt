Group 20
Deepesh Kumar Lall(170236) Srinjay Kumar(170722)

Q1. 	Run: insertAt 'X' "abcd" 2
	Output: abXcd

	As asked the function insert a charecter at the given index in the string and incase if index is greater than lenght of string it inserts charecter at end by default.

Q2.	Run: incrrange [1,2,3,4,5] (2 3)
	Output: [1 3 4 4 5]

	As asked the function take a list if integer and increase the given range by 1.

Q3.	Run: combination 3 "abcdef"
	Output: ["abc","abd","abe",...]

	As asked the function take a list of n items and return all the possible combination of item in the list.It is also to be noted that here we have assumed distinct entry of items in the list as because it is mentioned to be a list.
