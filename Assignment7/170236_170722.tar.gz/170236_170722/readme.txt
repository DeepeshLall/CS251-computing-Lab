1. Fibonacci Series:
	The code's function have been defined and commented in the code itself.
	As as per the question to find the nth Fibonacci number.
	Command : ehco -e "fib n" | ghci fib.hs
	To get the infinite list of all fibonacci number
	Command : echo -e "fibList" | ghci fib.hs

2. Prime Series:
	The code's function have been defined and commented in the code itself.
	As as per the question to find the nth Prime number.
	Command : ehco -e "prime n" | ghci prime.hs
	To get the infinite list of all prime number
	Command : echo -e "primeList" | ghci prime.hs	